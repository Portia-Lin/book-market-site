menu.onclick = function myFunction() {
	var x = document.getElementById('menu');

	if (x.className === "menu-itms") {
		x.className += " responsive";
	}
	else {
		x.className = "menu-itms";
	}
}
